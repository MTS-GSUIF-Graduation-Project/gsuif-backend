package com.example.inventory.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import com.example.inventory.entity.AuditableEntity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;
import com.example.inventory.dto.StockUnitCondition;
import java.util.UUID;
import java.time.LocalDate;
@Entity
@Table(name = "stock_unit")
public class StockUnit extends AuditableEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "id", updatable = false, nullable = false)
    private UUID id;

    @Column(name = "label", nullable = false, length = 100)
    private String label;

    @Enumerated(EnumType.STRING)
    @JdbcTypeCode(SqlTypes.VARCHAR)
    @Column(name = "condition", nullable = false)
    private StockUnitCondition condition;

    @Column(name = "retired_on", nullable = true)
    private LocalDate retiredOn;

    public StockUnit() {
    }

    public UUID getId() {
        return id;
    }

    protected void setId(UUID id) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public StockUnitCondition getCondition() {
        return condition;
    }

    public void setCondition(StockUnitCondition condition) {
        this.condition = condition;
    }

    public LocalDate getRetiredOn() {
        return retiredOn;
    }

    public void setRetiredOn(LocalDate retiredOn) {
        this.retiredOn = retiredOn;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StockUnit that)) return false;
        return id != null && id.equals(that.getId());
    }

    @Override
    public int hashCode() {
        return StockUnit.class.hashCode();
    }
}
