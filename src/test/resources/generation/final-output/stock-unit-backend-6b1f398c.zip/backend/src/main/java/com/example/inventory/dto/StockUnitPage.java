package com.example.inventory.dto;

public record StockUnitPage(
    java.util.List<StockUnitDto> data,
    int totalPages,
    long totalElements,
    int size,
    int number
) { }
