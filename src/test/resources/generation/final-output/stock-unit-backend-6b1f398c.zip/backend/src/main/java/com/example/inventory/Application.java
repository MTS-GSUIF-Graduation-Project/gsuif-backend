package com.example.inventory;

@org.springframework.boot.autoconfigure.SpringBootApplication
@org.springframework.context.annotation.ComponentScan(basePackages = "com.example.inventory",
        excludeFilters = @org.springframework.context.annotation.ComponentScan.Filter(
                type = org.springframework.context.annotation.FilterType.REGEX,
                pattern = "com.example.inventory\\.bootstrap\\..*"))
public class Application {
    public static void main(String[] args) {
        if (args.length > 0 && "bootstrap-admin".equals(args[0])) {
            int exit = com.example.inventory.bootstrap.FirstAdminBootstrap.run(args);
            if (exit != 0) System.exit(exit);
            return;
        }
        org.springframework.boot.SpringApplication.run(Application.class, args);
    }
}
