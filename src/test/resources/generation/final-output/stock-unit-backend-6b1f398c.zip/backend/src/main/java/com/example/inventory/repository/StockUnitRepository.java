package com.example.inventory.repository;

public interface StockUnitRepository extends
        org.springframework.data.jpa.repository.JpaRepository<com.example.inventory.entity.StockUnit, java.util.UUID>,
        org.springframework.data.jpa.repository.JpaSpecificationExecutor<com.example.inventory.entity.StockUnit> { }
