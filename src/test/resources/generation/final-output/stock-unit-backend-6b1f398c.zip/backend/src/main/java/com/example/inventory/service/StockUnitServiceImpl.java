package com.example.inventory.service;

import com.example.inventory.dto.CreateStockUnitRequest;
import com.example.inventory.dto.StockUnitCondition;
import com.example.inventory.dto.StockUnitDto;
import com.example.inventory.dto.StockUnitPage;
import com.example.inventory.dto.UpdateStockUnitRequest;
import com.example.inventory.entity.StockUnit;
import com.example.inventory.exception.RequestedRecordNotFoundException;
import com.example.inventory.repository.StockUnitRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class StockUnitServiceImpl implements StockUnitService {

    private final StockUnitRepository stockUnitRepository;

    public StockUnitServiceImpl(StockUnitRepository stockUnitRepository) {
        this.stockUnitRepository = stockUnitRepository;
    }

    @Override
    public StockUnitDto create(CreateStockUnitRequest request) {
        StockUnit entity = new StockUnit();
        entity.setLabel(request.label());
        entity.setCondition(request.condition());
        entity.setRetiredOn(request.retiredOn());
        StockUnit saved = stockUnitRepository.save(entity);
        return mapToDto(saved);
    }

    @Override
    public StockUnitDto getById(UUID id) {
        return stockUnitRepository.findById(id)
                .map(this::mapToDto)
                .orElseThrow(RequestedRecordNotFoundException::new);
    }

    @Override
    public StockUnitPage list(StockUnitCondition condition, String label, Integer page, Integer size) {
        int pageNumber = page != null ? page : 0;
        int pageSize = size != null ? Math.max(1, Math.min(size, 100)) : 20;

        Specification<StockUnit> spec = (root, query, criteriaBuilder) -> criteriaBuilder.conjunction();

        if (condition != null) {
            spec = spec.and((root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("condition"), condition));
        }

        if (label != null && !label.isEmpty()) {
            spec = spec.and((root, query, criteriaBuilder) -> criteriaBuilder.like(root.get("label"), "%%" + label + "%%"));
        }

        PageRequest pageRequest = PageRequest.of(pageNumber, pageSize, Sort.by(Sort.Direction.ASC, "id"));
        Page<StockUnit> result = stockUnitRepository.findAll(spec, pageRequest);

        List<StockUnitDto> data = result.getContent().stream().map(this::mapToDto).toList();

        return new StockUnitPage(data, result.getTotalPages(), result.getTotalElements(), pageSize, pageNumber);
    }

    @Override
    public StockUnitDto update(UUID id, UpdateStockUnitRequest request) {
        StockUnit entity = stockUnitRepository.findById(id)
                .orElseThrow(RequestedRecordNotFoundException::new);
        entity.setLabel(request.label());
        entity.setCondition(request.condition());
        entity.setRetiredOn(request.retiredOn());
        StockUnit updated = stockUnitRepository.save(entity);
        return mapToDto(updated);
    }

    @Override
    public void delete(UUID id) {
        if (!stockUnitRepository.existsById(id)) {
            throw new RequestedRecordNotFoundException();
        }
        stockUnitRepository.deleteById(id);
    }

    private StockUnitDto mapToDto(StockUnit entity) {
        return new StockUnitDto(
                entity.getId(),
                entity.getLabel(),
                entity.getCondition(),
                entity.getRetiredOn()
        );
    }
}
