package com.example.inventory.controller;

@org.springframework.web.bind.annotation.RestController
public class StockUnitController implements com.example.inventory.api.StockUnitApi {
    private final com.example.inventory.service.StockUnitService service;

    public StockUnitController(com.example.inventory.service.StockUnitService service) {
        this.service = service;
    }

    @Override
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
    @com.example.inventory.aspect.Loggable
    public org.springframework.http.ResponseEntity<com.example.inventory.api.ApiResponse<com.example.inventory.dto.StockUnitPage>> scanStockUnits(com.example.inventory.dto.StockUnitCondition condition, String label, Integer page, Integer size) {
        if (page == null || page < 0) return org.springframework.http.ResponseEntity.badRequest().body(
                com.example.inventory.api.ApiResponse.<com.example.inventory.dto.StockUnitPage>error(400, "Invalid request",
                        java.util.Map.of("page", "Invalid value")));
        if (size == null || size < 1) return org.springframework.http.ResponseEntity.badRequest().body(
                com.example.inventory.api.ApiResponse.<com.example.inventory.dto.StockUnitPage>error(400, "Invalid request",
                        java.util.Map.of("size", "Invalid value")));
        if (size == null || size > 100) return org.springframework.http.ResponseEntity.badRequest().body(
                com.example.inventory.api.ApiResponse.<com.example.inventory.dto.StockUnitPage>error(400, "Invalid request",
                        java.util.Map.of("size", "Invalid value")));
        var body = service.list(condition, label, page, size);
        return org.springframework.http.ResponseEntity.status(200).body(
                com.example.inventory.api.ApiResponse.success(body, "Success", 200));
    }

    @Override
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
    @com.example.inventory.aspect.Loggable
    public org.springframework.http.ResponseEntity<com.example.inventory.api.ApiResponse<com.example.inventory.dto.StockUnitDto>> registerStockUnit(com.example.inventory.dto.CreateStockUnitRequest request) {
        var body = service.create(request);
        return org.springframework.http.ResponseEntity.status(201).body(
                com.example.inventory.api.ApiResponse.success(body, "Success", 201));
    }

    @Override
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
    @com.example.inventory.aspect.Loggable
    public org.springframework.http.ResponseEntity<com.example.inventory.api.ApiResponse<com.example.inventory.dto.StockUnitDto>> inspectStockUnit(java.util.UUID id) {
        var body = service.getById(id);
        return org.springframework.http.ResponseEntity.status(200).body(
                com.example.inventory.api.ApiResponse.success(body, "Success", 200));
    }

    @Override
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
    @com.example.inventory.aspect.Loggable
    public org.springframework.http.ResponseEntity<com.example.inventory.api.ApiResponse<com.example.inventory.dto.StockUnitDto>> replaceStockUnit(java.util.UUID id, com.example.inventory.dto.UpdateStockUnitRequest request) {
        var body = service.update(id, request);
        return org.springframework.http.ResponseEntity.status(200).body(
                com.example.inventory.api.ApiResponse.success(body, "Success", 200));
    }

    @Override
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyAuthority('ROLE_ADMIN')")
    @com.example.inventory.aspect.Loggable
    public org.springframework.http.ResponseEntity<com.example.inventory.api.ApiResponse<Void>> discardStockUnit(java.util.UUID id) {
        service.delete(id);
        return org.springframework.http.ResponseEntity.status(200).body(
                com.example.inventory.api.ApiResponse.<Void>success(null, "Success", 200));
    }

}
