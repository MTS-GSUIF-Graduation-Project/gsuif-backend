package com.example.inventory.dto;

public enum StockUnitCondition { OPEN, CLOSED }
