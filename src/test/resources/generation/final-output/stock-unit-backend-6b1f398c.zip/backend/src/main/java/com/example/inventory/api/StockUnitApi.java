package com.example.inventory.api;

public interface StockUnitApi {
    @org.springframework.web.bind.annotation.RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.GET, path = "/api/v1/stock-units", produces = "application/json")
    @io.swagger.v3.oas.annotations.Operation(operationId = "scanStockUnits")
    @io.swagger.v3.oas.annotations.security.SecurityRequirement(name = "bearerAuth")
    @io.swagger.v3.oas.annotations.responses.ApiResponses({
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200",
                description = "Contracted success response", useReturnTypeSchema = true),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400",
                description = "Invalid request (runtime behavior; selected contract may omit this declaration)",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Authentication required",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Access denied",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "405", description = "Method not allowed",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Unexpected server error",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class)))
    })
    org.springframework.http.ResponseEntity<ApiResponse<com.example.inventory.dto.StockUnitPage>> scanStockUnits(@org.springframework.web.bind.annotation.RequestParam(name = "condition", required = true) com.example.inventory.dto.StockUnitCondition condition, @org.springframework.web.bind.annotation.RequestParam(name = "label", required = false) String label, @org.springframework.web.bind.annotation.RequestParam(name = "page", required = false, defaultValue = "0") Integer page, @org.springframework.web.bind.annotation.RequestParam(name = "size", required = false, defaultValue = "20") Integer size);

    @org.springframework.web.bind.annotation.RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.POST, path = "/api/v1/stock-units", produces = "application/json", consumes = "application/json")
    @io.swagger.v3.oas.annotations.Operation(operationId = "registerStockUnit")
    @io.swagger.v3.oas.annotations.security.SecurityRequirement(name = "bearerAuth")
    @io.swagger.v3.oas.annotations.responses.ApiResponses({
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "201",
                description = "Contracted success response", useReturnTypeSchema = true),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400",
                description = "Invalid request (runtime behavior; selected contract may omit this declaration)",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Authentication required",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Access denied",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "405", description = "Method not allowed",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "415", description = "Unsupported media type",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Unexpected server error",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class)))
    })
    org.springframework.http.ResponseEntity<ApiResponse<com.example.inventory.dto.StockUnitDto>> registerStockUnit(@jakarta.validation.Valid @org.springframework.web.bind.annotation.RequestBody com.example.inventory.dto.CreateStockUnitRequest request);

    @org.springframework.web.bind.annotation.RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.GET, path = "/api/v1/stock-units/{id}", produces = "application/json")
    @io.swagger.v3.oas.annotations.Operation(operationId = "inspectStockUnit")
    @io.swagger.v3.oas.annotations.security.SecurityRequirement(name = "bearerAuth")
    @io.swagger.v3.oas.annotations.responses.ApiResponses({
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200",
                description = "Contracted success response", useReturnTypeSchema = true),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400",
                description = "Invalid request (runtime behavior; selected contract may omit this declaration)",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Authentication required",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Access denied",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Requested record not found",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "405", description = "Method not allowed",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Unexpected server error",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class)))
    })
    org.springframework.http.ResponseEntity<ApiResponse<com.example.inventory.dto.StockUnitDto>> inspectStockUnit(@org.springframework.web.bind.annotation.PathVariable("id") java.util.UUID id);

    @org.springframework.web.bind.annotation.RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.PUT, path = "/api/v1/stock-units/{id}", produces = "application/json", consumes = "application/json")
    @io.swagger.v3.oas.annotations.Operation(operationId = "replaceStockUnit")
    @io.swagger.v3.oas.annotations.security.SecurityRequirement(name = "bearerAuth")
    @io.swagger.v3.oas.annotations.responses.ApiResponses({
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200",
                description = "Contracted success response", useReturnTypeSchema = true),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400",
                description = "Invalid request (runtime behavior; selected contract may omit this declaration)",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Authentication required",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Access denied",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Requested record not found",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "405", description = "Method not allowed",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "415", description = "Unsupported media type",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Unexpected server error",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class)))
    })
    org.springframework.http.ResponseEntity<ApiResponse<com.example.inventory.dto.StockUnitDto>> replaceStockUnit(@org.springframework.web.bind.annotation.PathVariable("id") java.util.UUID id, @jakarta.validation.Valid @org.springframework.web.bind.annotation.RequestBody com.example.inventory.dto.UpdateStockUnitRequest request);

    @org.springframework.web.bind.annotation.RequestMapping(method = org.springframework.web.bind.annotation.RequestMethod.DELETE, path = "/api/v1/stock-units/{id}", produces = "application/json")
    @io.swagger.v3.oas.annotations.Operation(operationId = "discardStockUnit")
    @io.swagger.v3.oas.annotations.security.SecurityRequirement(name = "bearerAuth")
    @io.swagger.v3.oas.annotations.responses.ApiResponses({
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "200",
                description = "Contracted success response", useReturnTypeSchema = true),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "400",
                description = "Invalid request (runtime behavior; selected contract may omit this declaration)",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "401", description = "Authentication required",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "403", description = "Access denied",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "404", description = "Requested record not found",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "405", description = "Method not allowed",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class))),
        @io.swagger.v3.oas.annotations.responses.ApiResponse(responseCode = "500", description = "Unexpected server error",
                content = @io.swagger.v3.oas.annotations.media.Content(mediaType = "application/json",
                        schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = ErrorApiResponse.class)))
    })
    org.springframework.http.ResponseEntity<ApiResponse<Void>> discardStockUnit(@org.springframework.web.bind.annotation.PathVariable("id") java.util.UUID id);

}
