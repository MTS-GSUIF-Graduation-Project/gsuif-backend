package com.example.inventory.dto;

public record CreateStockUnitRequest(
    @com.fasterxml.jackson.annotation.JsonProperty(value = "condition", required = true)
    @jakarta.validation.constraints.NotNull
    StockUnitCondition condition,
    @com.fasterxml.jackson.annotation.JsonProperty(value = "label", required = true)
    @jakarta.validation.constraints.NotNull
    String label,
    @com.fasterxml.jackson.annotation.JsonProperty(value = "retiredOn", required = true)
    java.time.LocalDate retiredOn
) { }
