package com.example.inventory.dto;

public record StockUnitDto(
    java.util.UUID id,
    String label,
    StockUnitCondition condition,
    java.time.LocalDate retiredOn
) { }
