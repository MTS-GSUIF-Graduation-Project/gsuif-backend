CREATE TABLE stock_unit (
    id uuid NOT NULL,
    condition varchar(255) NOT NULL,
    label varchar(100) NOT NULL,
    retired_on date,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    created_by varchar(100) NOT NULL,
    last_modified_by varchar(100) NOT NULL,
    CONSTRAINT pk_stock_unit PRIMARY KEY (id),
    CONSTRAINT ck_stock_unit_condition_enum CHECK (condition IN ('OPEN', 'CLOSED'))
);

CREATE TABLE user_accounts (
    id uuid NOT NULL,
    username varchar(100) NOT NULL,
    password_hash varchar(255) NOT NULL,
    enabled boolean NOT NULL,
    CONSTRAINT pk_user_accounts PRIMARY KEY (id),
    CONSTRAINT uq_user_accounts_username UNIQUE (username)
);

CREATE TABLE user_account_roles (
    user_id uuid NOT NULL,
    role varchar(32) NOT NULL,
    CONSTRAINT pk_user_account_roles PRIMARY KEY (user_id, role),
    CONSTRAINT ck_user_account_roles_role CHECK (role IN ('ROLE_ADMIN', 'ROLE_USER')),
    CONSTRAINT fk_user_account_roles_user FOREIGN KEY (user_id) REFERENCES user_accounts(id) ON DELETE RESTRICT
);
