package com.example.inventory.audit;

@org.springframework.context.annotation.Configuration(proxyBeanMethods = false)
@org.springframework.data.jpa.repository.config.EnableJpaAuditing(auditorAwareRef = "generatedAppAuditor")
public class AuditActorConfig {
    @org.springframework.context.annotation.Bean("generatedAppAuditor")
    org.springframework.data.domain.AuditorAware<String> generatedAppAuditor(
            com.example.inventory.security.SecurityMode mode, org.springframework.core.env.Environment environment) {
        return new GeneratedAppAuditorAware(mode, environment);
    }
}
