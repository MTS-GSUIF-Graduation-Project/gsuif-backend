package com.example.inventory.service;

/** getById, update and delete throw com.example.inventory.exception.RequestedRecordNotFoundException
 * only when the requested id is absent; other persistence failures propagate. */
public interface StockUnitService {
    com.example.inventory.dto.StockUnitDto create(com.example.inventory.dto.CreateStockUnitRequest request);
    com.example.inventory.dto.StockUnitDto getById(java.util.UUID id);
    /** Apply selected filters before pagination; use page and size from the method arguments. Sort by entity id ASC. Return totals for all matching records and empty data for an out-of-range page. */
    com.example.inventory.dto.StockUnitPage list(com.example.inventory.dto.StockUnitCondition condition, String label, Integer page, Integer size);
    com.example.inventory.dto.StockUnitDto update(java.util.UUID id, com.example.inventory.dto.UpdateStockUnitRequest request);
    void delete(java.util.UUID id);
}
